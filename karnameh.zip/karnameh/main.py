import sys
import sqlite3
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QHBoxLayout, QPushButton, QLabel, QFileDialog, 
                             QScrollArea, QGroupBox, QRadioButton, QButtonGroup,
                             QLineEdit, QMessageBox, QComboBox, QListWidget, 
                             QListWidgetItem, QDialog, QDialogButtonBox)
from PyQt5.QtGui import QPixmap, QPainter, QPen, QFont, QImage, QCursor
from PyQt5.QtCore import Qt, QPoint, QRect

class DraggableAnnotation:
    def __init__(self, field_name, x, y, symbol=None, text=None):
        self.field_name = field_name
        self.x = x
        self.y = y
        self.symbol = symbol
        self.text = text
        self.dragging = False
        self.hover = False
        
    def get_bounds(self):
        """محاسبه محدوده annotation برای تشخیص کلیک"""
        if self.text:
            width = len(self.text) * 10 + 40
            height = 30
        else:
            width = 20  # نصف شد
            height = 20  # نصف شد
        return QRect(self.x - 10, self.y - 10, width, height)  # نصف شد
    
    def contains_point(self, px, py):
        """بررسی اینکه نقطه داخل محدوده annotation است"""
        return self.get_bounds().contains(px, py)

class ImageLabel(QLabel):
    def __init__(self, parent):
        super().__init__()
        self.parent_app = parent
        self.setMinimumSize(800, 600)
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet("border: 2px solid #ccc; background-color: #f5f5f5;")
        self.original_pixmap = None
        self.scale_factor = 1.0
        self.offset_x = 0
        self.offset_y = 0
        self.dragging_annotation = None
        self.drag_offset_x = 0
        self.drag_offset_y = 0
        self.setMouseTracking(True)
        
    def setPixmapScaled(self, pixmap):
        self.original_pixmap = pixmap
        self.updateDisplay()
        
    def updateDisplay(self):
        """به‌روزرسانی نمایش تصویر با annotation‌ها"""
        if not self.original_pixmap:
            return
            
        # ایجاد کپی از تصویر اصلی
        pixmap = self.original_pixmap.copy()
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # رسم تمام annotation‌ها
        for field, annotation in self.parent_app.annotations.items():
            self.draw_annotation(painter, annotation)
        
        painter.end()
        
        # مقیاس‌بندی و نمایش
        scaled = pixmap.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.scale_factor = scaled.width() / self.original_pixmap.width()
        self.offset_x = (self.width() - scaled.width()) // 2
        self.offset_y = (self.height() - scaled.height()) // 2
        self.setPixmap(scaled)
    
    def draw_annotation(self, painter, annotation):
        """رسم یک annotation"""
        x, y = annotation.x, annotation.y
        
        # تغییر رنگ در صورت hover
        if annotation.hover:
            pen_color = Qt.darkGreen
            bg_color = Qt.yellow
        else:
            pen_color = Qt.red
            bg_color = Qt.white
        
        # رسم پس‌زمینه برای قابلیت drag
        painter.setPen(QPen(bg_color, 1))
        painter.setBrush(bg_color)
        bounds = annotation.get_bounds()
        painter.drawRect(bounds.adjusted(-1, -1, 1, 1))  # نصف شد
        
        # رسم سمبل
        if annotation.symbol:
            pen = QPen(pen_color, 2)  # نصف شد
            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)
            
            if annotation.symbol == 'circle':
                painter.drawEllipse(QPoint(x, y), 7, 7)  # نصف شد
            elif annotation.symbol == 'cross':
                painter.drawLine(x-5, y-5, x+5, y+5)  # نصف شد
                painter.drawLine(x-5, y+5, x+5, y-5)  # نصف شد
            elif annotation.symbol == 'check':
                painter.drawLine(x-5, y, x-2, y+5)  # نصف شد
                painter.drawLine(x-2, y+5, x+7, y-5)  # نصف شد
            elif annotation.symbol == 'line':
                painter.drawLine(x-7, y, x+7, y)  # نصف شد
            elif annotation.symbol == 'hash':
                for i in range(-5, 7, 2):  # نصف شد
                    painter.drawLine(x+i, y-5, x+i, y+5)  # نصف شد
        
        # نوشتن متن
        if annotation.text:
            font = QFont('Arial', 18, QFont.Bold)  # افزایش اندازه فونت
            painter.setFont(font)
            painter.setPen(QPen(Qt.blue, 2))  # افزایش ضخامت خط
            painter.drawText(x + 10, y, annotation.text)  # نصف شد
    
    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.updateDisplay()
    
    def screenToImageCoords(self, sx, sy):
        """تبدیل مختصات صفحه به مختصات تصویر اصلی"""
        if self.original_pixmap:
            image_x = (sx - self.offset_x) / self.scale_factor
            image_y = (sy - self.offset_y) / self.scale_factor
            return int(image_x), int(image_y)
        return sx, sy
    
    def mousePressEvent(self, event):
        if not self.parent_app.image_path:
            return
        
        x, y = self.screenToImageCoords(event.pos().x(), event.pos().y())
        
        # بررسی کلیک روی annotation موجود
        for field, annotation in self.parent_app.annotations.items():
            if annotation.contains_point(x, y):
                self.dragging_annotation = annotation
                self.drag_offset_x = x - annotation.x
                self.drag_offset_y = y - annotation.y
                annotation.dragging = True
                self.setCursor(QCursor(Qt.ClosedHandCursor))
                return
        
        # اگر annotation جدید باید اضافه شود
        if self.parent_app.current_field:
            if self.parent_app.current_field not in self.parent_app.annotations:
                self.parent_app.annotations[self.parent_app.current_field] = DraggableAnnotation(
                    self.parent_app.current_field, x, y
                )
            else:
                ann = self.parent_app.annotations[self.parent_app.current_field]
                ann.x = x
                ann.y = y
            
            # به‌روزرسانی متن
            if self.parent_app.current_field in self.parent_app.text_inputs:
                text = self.parent_app.text_inputs[self.parent_app.current_field].text()
                if text:
                    self.parent_app.annotations[self.parent_app.current_field].text = text
            
            # به‌روزرسانی متن برای گزینه‌های دلخواه
            if self.parent_app.current_field in self.parent_app.custom_text_inputs:
                text = self.parent_app.custom_text_inputs[self.parent_app.current_field].text()
                if text:
                    self.parent_app.annotations[self.parent_app.current_field].text = text
            
            # به‌روزرسانی سمبل برای گزینه‌های دلخواه
            if self.parent_app.current_field in self.parent_app.custom_symbol_inputs:
                symbol = self.parent_app.custom_symbol_inputs[self.parent_app.current_field].currentText()
                if symbol != "انتخاب":
                    symbol_map = {
                        "⭕ دایره": "circle",
                        "❌ ضربدر": "cross",
                        "✓ چک": "check",
                        "➖ خط": "line",
                        "▓ هاشور": "hash"
                    }
                    self.parent_app.annotations[self.parent_app.current_field].symbol = symbol_map[symbol]
            
            self.updateDisplay()
            self.parent_app.status_label.setText(f"✓ موقعیت '{self.parent_app.current_field}' ثبت شد")
            self.parent_app.current_field = None
    
    def mouseMoveEvent(self, event):
        if not self.parent_app.image_path:
            return
        
        x, y = self.screenToImageCoords(event.pos().x(), event.pos().y())
        
        # در حال drag کردن
        if self.dragging_annotation:
            self.dragging_annotation.x = x - self.drag_offset_x
            self.dragging_annotation.y = y - self.drag_offset_y
            self.updateDisplay()
            return
        
        # بررسی hover
        found_hover = False
        for field, annotation in self.parent_app.annotations.items():
            if annotation.contains_point(x, y):
                if not annotation.hover:
                    annotation.hover = True
                    self.updateDisplay()
                self.setCursor(QCursor(Qt.OpenHandCursor))
                found_hover = True
            else:
                if annotation.hover:
                    annotation.hover = False
                    self.updateDisplay()
        
        if not found_hover:
            self.setCursor(QCursor(Qt.ArrowCursor))
    
    def mouseReleaseEvent(self, event):
        if self.dragging_annotation:
            self.dragging_annotation.dragging = False
            self.dragging_annotation = None
            self.setCursor(QCursor(Qt.OpenHandCursor))
            self.parent_app.status_label.setText("✓ موقعیت تنظیم شد - برای ذخیره دکمه 'ذخیره موقعیت‌ها' را بزنید")

class CustomFieldDialog(QDialog):
    def __init__(self, parent=None, field_name=None, field_type=None, field_value=None):
        super().__init__(parent)
        self.setWindowTitle("گزینه دلخواه جدید")
        self.setMinimumWidth(300)
        
        layout = QVBoxLayout()
        
        # نام فیلد
        name_layout = QHBoxLayout()
        name_label = QLabel("نام گزینه:")
        self.name_input = QLineEdit(field_name if field_name else "")
        name_layout.addWidget(name_label)
        name_layout.addWidget(self.name_input)
        layout.addLayout(name_layout)
        
        # نوع فیلد
        type_layout = QHBoxLayout()
        type_label = QLabel("نوع مقدار:")
        self.type_combo = QComboBox()
        self.type_combo.addItems(["متن", "آیکون"])
        if field_type:
            self.type_combo.setCurrentText(field_type)
        type_layout.addWidget(type_label)
        type_layout.addWidget(self.type_combo)
        layout.addLayout(type_layout)
        
        # مقدار متن
        self.text_widget = QWidget()
        text_layout = QHBoxLayout()
        text_label = QLabel("متن:")
        self.text_input = QLineEdit(field_value if field_type == "متن" and field_value else "")
        text_layout.addWidget(text_label)
        text_layout.addWidget(self.text_input)
        self.text_widget.setLayout(text_layout)
        layout.addWidget(self.text_widget)
        
        # مقدار آیکون
        self.symbol_widget = QWidget()
        symbol_layout = QHBoxLayout()
        symbol_label = QLabel("آیکون:")
        self.symbol_combo = QComboBox()
        self.symbol_combo.addItems(["انتخاب", "⭕ دایره", "❌ ضربدر", "✓ چک", "➖ خط", "▓ هاشور"])
        if field_type == "آیکون" and field_value:
            self.symbol_combo.setCurrentText(field_value)
        symbol_layout.addWidget(symbol_label)
        symbol_layout.addWidget(self.symbol_combo)
        self.symbol_widget.setLayout(symbol_layout)
        layout.addWidget(self.symbol_widget)
        
        # دکمه‌ها
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        
        # نمایش/پنهان کردن بر اساس نوع
        self.type_combo.currentTextChanged.connect(self.toggle_inputs)
        self.toggle_inputs(self.type_combo.currentText())
        
        self.setLayout(layout)
    
    def toggle_inputs(self, text):
        if text == "متن":
            self.text_widget.show()
            self.symbol_widget.hide()
        else:
            self.text_widget.hide()
            self.symbol_widget.show()
    
    def get_values(self):
        field_name = self.name_input.text()
        field_type = self.type_combo.currentText()
        
        if field_type == "متن":
            field_value = self.text_input.text()
        else:
            field_value = self.symbol_combo.currentText()
        
        return field_name, field_type, field_value

class CarInspectionApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("فرم ارزیابی کارشناسی خودرو")
        self.setGeometry(100, 100, 1400, 850)
        self.setLayoutDirection(Qt.RightToLeft)
        
        self.image_path = None
        self.current_field = None
        self.annotations = {}
        self.text_inputs = {}
        self.custom_fields = {}  # برای نگهداری گزینه‌های دلخواه
        self.custom_text_inputs = {}  # برای نگهداری ورودی‌های متن گزینه‌های دلخواه
        self.custom_symbol_inputs = {}  # برای نگهداری ورودی‌های آیکون گزینه‌های دلخواه
        self.custom_fields_widgets = {}  # برای نگهداری ویجت‌های گزینه‌های دلخواه
        
        self.init_database()
        self.init_ui()
        
    def init_database(self):
        self.conn = sqlite3.connect('car_inspection.db')
        self.cursor = self.conn.cursor()
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS annotations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                field_name TEXT,
                x INTEGER,
                y INTEGER,
                symbol TEXT,
                text_value TEXT,
                image_path TEXT
            )
        ''')
        
        # جدول جدید برای گزینه‌های دلخواه
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS custom_fields (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                field_name TEXT,
                field_type TEXT,
                field_value TEXT,
                image_path TEXT
            )
        ''')
        
        self.conn.commit()
        
    def init_ui(self):
        main_widget = QWidget()
        main_layout = QVBoxLayout()
        
        # نوار وضعیت در بالا
        self.status_label = QLabel("آماده - تصویر خود را بارگذاری کنید")
        self.status_label.setStyleSheet("""
            background-color: #e3f2fd; 
            padding: 10px; 
            font-size: 13px; 
            border-radius: 5px;
            color: #1976d2;
            font-weight: bold;
        """)
        main_layout.addWidget(self.status_label)
        
        # بخش اصلی
        content_layout = QHBoxLayout()
        
        # بخش راست - فرم
        form_scroll = QScrollArea()
        form_scroll.setWidgetResizable(True)
        form_scroll.setMaximumWidth(450)
        form_widget = QWidget()
        form_layout = QVBoxLayout()
        
        # دکمه انتخاب تصویر
        btn_browse = QPushButton("📁 انتخاب تصویر")
        btn_browse.setStyleSheet("padding: 10px; font-size: 14px; background-color: #4CAF50; color: white;")
        btn_browse.clicked.connect(self.load_image)
        form_layout.addWidget(btn_browse)
        
        # راهنما
        guide_label = QLabel("💡 راهنما:\n• برای افزودن: انتخاب موقعیت → کلیک روی تصویر\n• برای جابجایی: Drag کنید\n• موس را روی علامت‌ها ببرید تا قابل drag شوند")
        guide_label.setStyleSheet("background-color: #fff3cd; padding: 8px; border-radius: 5px; font-size: 11px;")
        guide_label.setWordWrap(True)
        form_layout.addWidget(guide_label)
        
        # اطلاعات متنی
        self.create_text_fields(form_layout)
        
        # رنگ و بدنه
        self.create_color_body_section(form_layout)
        
        # تست موتور
        self.create_motor_test_section(form_layout)
        
        # ایپشن‌ها
        self.create_options_section(form_layout)
        
        # تست فنی
        self.create_technical_test_section(form_layout)
        
        # گزینه‌های دلخواه
        self.create_custom_fields_section(form_layout)
        
        # دکمه‌های ذخیره و خروجی
        btn_layout = QVBoxLayout()
        
        btn_save_pos = QPushButton("💾 ذخیره موقعیت‌ها")
        btn_save_pos.setStyleSheet("padding: 10px; font-size: 14px; background-color: #9C27B0; color: white;")
        btn_save_pos.clicked.connect(self.save_positions)
        
        btn_save = QPushButton("💾 ذخیره کامل در دیتابیس")
        btn_save.setStyleSheet("padding: 10px; font-size: 14px; background-color: #2196F3; color: white;")
        btn_save.clicked.connect(self.save_to_database)
        
        btn_export = QPushButton("📤 خروجی تصویر نهایی")
        btn_export.setStyleSheet("padding: 10px; font-size: 14px; background-color: #FF9800; color: white;")
        btn_export.clicked.connect(self.export_image)
        
        btn_layout.addWidget(btn_save_pos)
        btn_layout.addWidget(btn_save)
        btn_layout.addWidget(btn_export)
        form_layout.addLayout(btn_layout)
        
        form_layout.addStretch()
        form_widget.setLayout(form_layout)
        form_scroll.setWidget(form_widget)
        
        # بخش چپ - تصویر
        self.image_label = ImageLabel(self)
        
        content_layout.addWidget(form_scroll)
        content_layout.addWidget(self.image_label, 1)
        
        main_layout.addLayout(content_layout)
        
        main_widget.setLayout(main_layout)
        self.setCentralWidget(main_widget)
        
    def create_text_fields(self, layout):
        group = QGroupBox("اطلاعات فرم")
        group_layout = QVBoxLayout()
        
        text_fields = [
            "نام درخواست کننده", "تلفن درخواست کننده", "نام فروشنده", 
            "تلفن فروشنده", "نوع خودرو", "تیپ خودرو", 
            "شماره موتور", "شماره شاسی", "انتقال‌ بیمه",
            "کیلومتر زمان کارشناسی", "رنگ خودرو", "سال ساخت"
        ]
        
        for field in text_fields:
            h_layout = QHBoxLayout()
            
            label = QLabel(field + ":")
            label.setMinimumWidth(150)
            
            input_field = QLineEdit()
            input_field.setPlaceholderText(f"متن را وارد کنید")
            input_field.textChanged.connect(lambda text, f=field: self.text_changed(f, text))
            self.text_inputs[field] = input_field
            
            btn_set = QPushButton("📍")
            btn_set.clicked.connect(lambda checked, f=field: self.set_current_field(f))
            btn_set.setMaximumWidth(40)
            btn_set.setToolTip("انتخاب موقعیت روی تصویر")
            
            h_layout.addWidget(label)
            h_layout.addWidget(input_field)
            h_layout.addWidget(btn_set)
            
            group_layout.addLayout(h_layout)
        
        group.setLayout(group_layout)
        layout.addWidget(group)
        
    def create_color_body_section(self, layout):
        group = QGroupBox("رنگ و بدنه")
        group_layout = QVBoxLayout()
        
        items = ["سقف", "شاسی جلو", "شاسی عقب", "ستون‌ها"]
        
        for item in items:
            item_layout = self.create_symbol_selector(item)
            group_layout.addLayout(item_layout)
        
        group.setLayout(group_layout)
        layout.addWidget(group)
        
    def create_motor_test_section(self, layout):
        group = QGroupBox("تست موتور")
        group_layout = QVBoxLayout()
        
        items = ["دود اگزوز", "نشت آب", "نشت روغن", "کارکرد درجا", 
                "عملکرد آمپرها", "واشر سرسیلندر", "وضعیت ظاهری موتور"]
        
        for item in items:
            item_layout = self.create_symbol_selector(item)
            group_layout.addLayout(item_layout)
        
        group.setLayout(group_layout)
        layout.addWidget(group)
        
    def create_options_section(self, layout):
        group = QGroupBox("ایپشن‌ها")
        group_layout = QVBoxLayout()
        
        items = ["دیاگ", "سانروف", "سنسورها", "زاپاس", "آینه ها", 
                "کمربند ایمنی", "سیستم فرمان", "شیشه بالابرها", 
                "برف‌پاک کن‌ها", "مکانیزم گرمایش", "مکانیزم سرمایش", 
                "عملکرد چراغ‌ها", "وضعیت صندلی خودرو"]
        
        for item in items:
            item_layout = self.create_symbol_selector(item)
            group_layout.addLayout(item_layout)
        
        group.setLayout(group_layout)
        layout.addWidget(group)
        
    def create_technical_test_section(self, layout):
        group = QGroupBox("تست فنی")
        group_layout = QVBoxLayout()
        
        items = ["تست رانندگی", "بلوس‌ها", "روغن سوزی", "میزان فرمان",
                "دیسک و صفحه", "بلبرینگ چرخ‌ها", "وضعیت گیربکس",
                "تیر‌مرها، روغن تیرمز"]
        
        for item in items:
            item_layout = self.create_symbol_selector(item)
            group_layout.addLayout(item_layout)
        
        group.setLayout(group_layout)
        layout.addWidget(group)
        
    def create_custom_fields_section(self, layout):
        self.custom_fields_group = QGroupBox("گزینه‌های دلخواه")
        group_layout = QVBoxLayout()
        
        # دکمه افزودن گزینه جدید
        btn_add_custom = QPushButton("➕ افزودن گزینه جدید")
        btn_add_custom.setStyleSheet("padding: 8px; font-size: 13px; background-color: #009688; color: white;")
        btn_add_custom.clicked.connect(self.add_custom_field)
        group_layout.addWidget(btn_add_custom)
        
        # لیست گزینه‌های دلخواه
        self.custom_fields_list = QListWidget()
        self.custom_fields_list.setMaximumHeight(150)
        group_layout.addWidget(self.custom_fields_list)
        
        # ویجت برای نگهداری گزینه‌های دلخواه
        self.custom_fields_container = QWidget()
        self.custom_fields_layout = QVBoxLayout()
        self.custom_fields_container.setLayout(self.custom_fields_layout)
        group_layout.addWidget(self.custom_fields_container)
        
        self.custom_fields_group.setLayout(group_layout)
        layout.addWidget(self.custom_fields_group)
        
    def create_symbol_selector(self, item_name):
        h_layout = QHBoxLayout()
        
        label = QLabel(item_name + ":")
        label.setMinimumWidth(150)
        
        btn_set_pos = QPushButton("📍")
        btn_set_pos.clicked.connect(lambda: self.set_current_field(item_name))
        btn_set_pos.setMaximumWidth(40)
        btn_set_pos.setToolTip("انتخاب موقعیت")
        
        combo = QComboBox()
        combo.addItems(["انتخاب", "⭕ دایره", "❌ ضربدر", "✓ چک", "➖ خط", "▓ هاشور"])
        combo.currentTextChanged.connect(lambda text, name=item_name: self.symbol_selected(name, text))
        combo.setMaximumWidth(130)
        
        h_layout.addWidget(label)
        h_layout.addWidget(btn_set_pos)
        h_layout.addWidget(combo)
        
        return h_layout
    
    def text_changed(self, field, text):
        """به‌روزرسانی زنده متن"""
        if field in self.annotations:
            self.annotations[field].text = text
            self.image_label.updateDisplay()
        
    def set_current_field(self, field_name):
        self.current_field = field_name
        self.status_label.setText(f"👆 حالا روی تصویر کلیک کنید تا موقعیت '{field_name}' مشخص شود")
        
    def symbol_selected(self, item_name, symbol_text):
        """به‌روزرسانی زنده سمبل"""
        symbol_map = {
            "⭕ دایره": "circle",
            "❌ ضربدر": "cross",
            "✓ چک": "check",
            "➖ خط": "line",
            "▓ هاشور": "hash"
        }
        
        if symbol_text in symbol_map:
            if item_name not in self.annotations:
                # ایجاد annotation جدید در مرکز تصویر
                if self.image_path:
                    pixmap = QPixmap(self.image_path)
                    center_x = pixmap.width() // 2
                    center_y = pixmap.height() // 2
                    self.annotations[item_name] = DraggableAnnotation(
                        item_name, center_x, center_y, symbol_map[symbol_text]
                    )
                    self.status_label.setText(f"✓ سمبل '{item_name}' اضافه شد - می‌توانید آن را جابجا کنید")
            else:
                self.annotations[item_name].symbol = symbol_map[symbol_text]
                self.status_label.setText(f"✓ سمبل '{item_name}' تغییر کرد")
            
            self.image_label.updateDisplay()
    
    def add_custom_field(self):
        dialog = CustomFieldDialog(self)
        if dialog.exec_():
            field_name, field_type, field_value = dialog.get_values()
            
            if not field_name:
                QMessageBox.warning(self, "خطا", "نام گزینه را وارد کنید")
                return
            
            if field_type == "آیکون" and field_value == "انتخاب":
                QMessageBox.warning(self, "خطا", "یک آیکون انتخاب کنید")
                return
            
            # اضافه کردن به لیست گزینه‌های دلخواه
            self.custom_fields[field_name] = {
                'type': field_type,
                'value': field_value
            }
            
            # اضافه کردن به لیست نمایش
            item_text = f"{field_name} ({field_type}: {field_value})"
            item = QListWidgetItem(item_text)
            item.setData(Qt.UserRole, field_name)
            self.custom_fields_list.addItem(item)
            
            # ایجاد ویجت برای گزینه جدید
            field_widget = QWidget()
            field_layout = QHBoxLayout()
            
            label = QLabel(field_name + ":")
            label.setMinimumWidth(150)
            
            btn_set_pos = QPushButton("📍")
            btn_set_pos.clicked.connect(lambda checked, f=field_name: self.set_current_field(f))
            btn_set_pos.setMaximumWidth(40)
            btn_set_pos.setToolTip("انتخاب موقعیت روی تصویر")
            
            if field_type == "متن":
                input_field = QLineEdit(field_value)
                input_field.textChanged.connect(lambda text, f=field_name: self.custom_text_changed(f, text))
                self.custom_text_inputs[field_name] = input_field
                field_layout.addWidget(label)
                field_layout.addWidget(input_field)
                field_layout.addWidget(btn_set_pos)
            else:
                combo = QComboBox()
                combo.addItems(["انتخاب", "⭕ دایره", "❌ ضربدر", "✓ چک", "➖ خط", "▓ هاشور"])
                combo.setCurrentText(field_value)
                combo.currentTextChanged.connect(lambda text, f=field_name: self.custom_symbol_changed(f, text))
                self.custom_symbol_inputs[field_name] = combo
                field_layout.addWidget(label)
                field_layout.addWidget(btn_set_pos)
                field_layout.addWidget(combo)
            
            field_widget.setLayout(field_layout)
            self.custom_fields_layout.addWidget(field_widget)
            self.custom_fields_widgets[field_name] = field_widget
            
            # ایجاد annotation در مرکز تصویر
            if self.image_path:
                pixmap = QPixmap(self.image_path)
                center_x = pixmap.width() // 2
                center_y = pixmap.height() // 2
                
                if field_type == "متن":
                    self.annotations[field_name] = DraggableAnnotation(
                        field_name, center_x, center_y, text=field_value
                    )
                else:
                    symbol_map = {
                        "⭕ دایره": "circle",
                        "❌ ضربدر": "cross",
                        "✓ چک": "check",
                        "➖ خط": "line",
                        "▓ هاشور": "hash"
                    }
                    symbol = symbol_map.get(field_value, "")
                    self.annotations[field_name] = DraggableAnnotation(
                        field_name, center_x, center_y, symbol=symbol
                    )
                
                self.image_label.updateDisplay()
                self.status_label.setText(f"✓ گزینه دلخواه '{field_name}' اضافه شد - می‌توانید آن را جابجا کنید")
    
    def custom_text_changed(self, field, text):
        """به‌روزرسانی زنده متن گزینه دلخواه"""
        if field in self.annotations:
            self.annotations[field].text = text
            self.image_label.updateDisplay()
    
    def custom_symbol_changed(self, field, symbol_text):
        """به‌روزرسانی زنده سمبل گزینه دلخواه"""
        symbol_map = {
            "⭕ دایره": "circle",
            "❌ ضربدر": "cross",
            "✓ چک": "check",
            "➖ خط": "line",
            "▓ هاشور": "hash"
        }
        
        if symbol_text in symbol_map:
            if field in self.annotations:
                self.annotations[field].symbol = symbol_map[symbol_text]
                self.image_label.updateDisplay()
    
    def load_image(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "انتخاب تصویر", "", "Image Files (*.png *.jpg *.jpeg *.bmp)"
        )
        
        if file_path:
            self.image_path = file_path
            pixmap = QPixmap(file_path)
            self.image_label.setPixmapScaled(pixmap)
            self.annotations.clear()
            self.custom_fields.clear()
            self.custom_text_inputs.clear()
            self.custom_symbol_inputs.clear()
            self.custom_fields_list.clear()
            
            # پاک کردن ویجت‌های گزینه‌های دلخواه
            for i in reversed(range(self.custom_fields_layout.count())): 
                self.custom_fields_layout.itemAt(i).widget().setParent(None)
            self.custom_fields_widgets.clear()
            
            # بارگذاری گزینه‌های دلخواه از دیتابیس
            self.cursor.execute('SELECT field_name, field_type, field_value FROM custom_fields WHERE image_path = ?', (file_path,))
            for row in self.cursor.fetchall():
                field_name, field_type, field_value = row
                
                # اضافه کردن به لیست گزینه‌های دلخواه
                self.custom_fields[field_name] = {
                    'type': field_type,
                    'value': field_value
                }
                
                # اضافه کردن به لیست نمایش
                item_text = f"{field_name} ({field_type}: {field_value})"
                item = QListWidgetItem(item_text)
                item.setData(Qt.UserRole, field_name)
                self.custom_fields_list.addItem(item)
                
                # ایجاد ویجت برای گزینه جدید
                field_widget = QWidget()
                field_layout = QHBoxLayout()
                
                label = QLabel(field_name + ":")
                label.setMinimumWidth(150)
                
                btn_set_pos = QPushButton("📍")
                btn_set_pos.clicked.connect(lambda checked, f=field_name: self.set_current_field(f))
                btn_set_pos.setMaximumWidth(40)
                btn_set_pos.setToolTip("انتخاب موقعیت روی تصویر")
                
                if field_type == "متن":
                    input_field = QLineEdit(field_value)
                    input_field.textChanged.connect(lambda text, f=field_name: self.custom_text_changed(f, text))
                    self.custom_text_inputs[field_name] = input_field
                    field_layout.addWidget(label)
                    field_layout.addWidget(input_field)
                    field_layout.addWidget(btn_set_pos)
                else:
                    combo = QComboBox()
                    combo.addItems(["انتخاب", "⭕ دایره", "❌ ضربدر", "✓ چک", "➖ خط", "▓ هاشور"])
                    combo.setCurrentText(field_value)
                    combo.currentTextChanged.connect(lambda text, f=field_name: self.custom_symbol_changed(f, text))
                    self.custom_symbol_inputs[field_name] = combo
                    field_layout.addWidget(label)
                    field_layout.addWidget(btn_set_pos)
                    field_layout.addWidget(combo)
                
                field_widget.setLayout(field_layout)
                self.custom_fields_layout.addWidget(field_widget)
                self.custom_fields_widgets[field_name] = field_widget
            
            # بارگذاری annotations از دیتابیس
            self.cursor.execute('SELECT field_name, x, y, symbol, text_value FROM annotations WHERE image_path = ?', (file_path,))
            for row in self.cursor.fetchall():
                field_name, x, y, symbol, text_value = row
                annotation = DraggableAnnotation(field_name, x, y, symbol, text_value)
                self.annotations[field_name] = annotation
            
            self.image_label.updateDisplay()
            self.status_label.setText("✓ تصویر بارگذاری شد - شروع کنید!")
    
    def save_positions(self):
        """ذخیره موقعیت‌ها"""
        if not self.annotations:
            QMessageBox.warning(self, "خطا", "هیچ موقعیتی برای ذخیره وجود ندارد")
            return
        
        count = len(self.annotations)
        self.status_label.setText(f"✓ {count} موقعیت ذخیره شد")
        QMessageBox.information(self, "موفق", f"{count} موقعیت با موفقیت ذخیره شد")
        
    def save_to_database(self):
        if not self.image_path:
            QMessageBox.warning(self, "خطا", "هیچ تصویری انتخاب نشده است")
            return
        
        # حذف اطلاعات قبلی
        self.cursor.execute('DELETE FROM annotations WHERE image_path = ?', (self.image_path,))
        self.cursor.execute('DELETE FROM custom_fields WHERE image_path = ?', (self.image_path,))
        
        # ذخیره annotations
        for field, annotation in self.annotations.items():
            self.cursor.execute('''
                INSERT INTO annotations (field_name, x, y, symbol, text_value, image_path)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (field, annotation.x, annotation.y, annotation.symbol or '', 
                  annotation.text or '', self.image_path))
        
        # ذخیره گزینه‌های دلخواه
        for field_name, field_data in self.custom_fields.items():
            self.cursor.execute('''
                INSERT INTO custom_fields (field_name, field_type, field_value, image_path)
                VALUES (?, ?, ?, ?)
            ''', (field_name, field_data['type'], field_data['value'], self.image_path))
        
        self.conn.commit()
        self.status_label.setText("✓ اطلاعات در دیتابیس ذخیره شد")
        QMessageBox.information(self, "موفق", "اطلاعات با موفقیت در دیتابیس ذخیره شد")
        
    def export_image(self):
        if not self.image_path:
            QMessageBox.warning(self, "خطا", "هیچ تصویری انتخاب نشده است")
            return
        
        save_path, _ = QFileDialog.getSaveFileName(
            self, "ذخیره تصویر", "", "PNG Files (*.png);;JPEG Files (*.jpg)"
        )
        
        if save_path:
            pixmap = QPixmap(self.image_path)
            painter = QPainter(pixmap)
            painter.setRenderHint(QPainter.Antialiasing)
            
            for field, annotation in self.annotations.items():
                x, y = annotation.x, annotation.y
                
                if annotation.symbol:
                    pen = QPen(Qt.red, 2)  # نصف شد
                    painter.setPen(pen)
                    
                    if annotation.symbol == 'circle':
                        painter.drawEllipse(QPoint(x, y), 10, 10)  # نصف شد
                    elif annotation.symbol == 'cross':
                        painter.drawLine(x-7, y-7, x+7, y+7)  # نصف شد
                        painter.drawLine(x-7, y+7, x+7, y-7)  # نصف شد
                    elif annotation.symbol == 'check':
                        painter.drawLine(x-7, y, x-3, y+7)  # نصف شد
                        painter.drawLine(x-3, y+7, x+10, y-7)  # نصف شد
                    elif annotation.symbol == 'line':
                        painter.drawLine(x-10, y, x+10, y)  # نصف شد
                    elif annotation.symbol == 'hash':
                        for i in range(-7, 10, 2):  # نصف شد
                            painter.drawLine(x+i, y-7, x+i, y+7)  # نصف شد
                
                if annotation.text:
                    font = QFont('Arial', 18, QFont.Bold)  # افزایش اندازه فونت
                    painter.setFont(font)
                    painter.setPen(QPen(Qt.blue, 2))  # افزایش ضخامت خط
                    painter.drawText(x + 10, y, annotation.text)  # نصف شد
            
            painter.end()
            pixmap.save(save_path)
            self.status_label.setText(f"✓ تصویر در {save_path} ذخیره شد")
            QMessageBox.information(self, "موفق", f"تصویر با موفقیت ذخیره شد")
    
    def closeEvent(self, event):
        self.conn.close()
        event.accept()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    window = CarInspectionApp()
    window.show()
    sys.exit(app.exec_())